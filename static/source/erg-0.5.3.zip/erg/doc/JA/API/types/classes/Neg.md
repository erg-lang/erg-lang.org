# Neg

[![badge](https://img.shields.io/endpoint.svg?url=https%3A%2F%2Fgezf7g7pd5.execute-api.ap-northeast-1.amazonaws.com%2Fdefault%2Fsource_up_to_date%3Fowner%3Derg-lang%26repos%3Derg%26ref%3Dmain%26path%3Ddoc/EN/API/types/classes/Neg.md%26commit_hash%3D290c43b09f7c3036112a164bed5fd07a1f6a5cda)](https://gezf7g7pd5.execute-api.ap-northeast-1.amazonaws.com/default/source_up_to_date?owner=erg-lang&repos=erg&ref=main&path=doc/EN/API/types/classes/Neg.md&commit_hash=290c43b09f7c3036112a164bed5fd07a1f6a5cda)

負の整数を表す型です。Pos and Neg and {0} == Intとなります。
ゼロ除算が起きない、Neg * Neg == Posとなるなど、いくつか特筆すべき性質も持っています。

## def

Inf<..-1
