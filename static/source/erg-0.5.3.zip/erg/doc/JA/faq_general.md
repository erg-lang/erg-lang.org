# Erg FAQ

[![badge](https://img.shields.io/endpoint.svg?url=https%3A%2F%2Fgezf7g7pd5.execute-api.ap-northeast-1.amazonaws.com%2Fdefault%2Fsource_up_to_date%3Fowner%3Derg-lang%26repos%3Derg%26ref%3Dmain%26path%3Ddoc/EN/faq_general.md%26commit_hash%3D521426cba21ed8b6eae5aff965dd14ef99af1228)](https://gezf7g7pd5.execute-api.ap-northeast-1.amazonaws.com/default/source_up_to_date?owner=erg-lang&repos=erg&ref=main&path=doc/EN/faq_general.md&commit_hash=521426cba21ed8b6eae5aff965dd14ef99af1228)

このFAQは一般のErg入門者向けです。
個別の(よくある)技術的な問題については[こちら](./faq_technical.md)を、文法の決定経緯(なぜこのような文法になったのか)などについては
[こちら](./faq_syntax.md)を参照してください。

## ErgはPython互換言語というのはどういう意味なのですか?

~~A: Ergの実行系であるEVM(Erg VirtualMachine)はPythonバイトコードを拡張したErgバイトコードを実行します。これは静的型付けシステムなどをPythonバイトコードに導入したものです(引数を取らない命令に引数を導入したり、空き番号に独自命令を実装しています)。これにより、ErgはPythonのコードをシームレスに呼び出し、かつ高速な実行を実現しています。~~

A: ErgスクリプトはPythonのバイトコードにトランスパイルされます。つまり、Pythonと同じインタープリタ上で動作します。もともとはPythonインタープリタ(CPython)を拡張した上位互換処理系を開発し、コンパイラと合わせて「Erg」とする予定でしたが、処理系の開発がコンパイラに対して大きく遅れたため、コンパイラのみ先行公開する運びとしました。現在処理系は鋭意開発中です。

## Ergはどの言語から影響を受けましたか?

両手でも数え切れないほどの言語から影響を受けていますが、中でも特に強く影響を受けているのはPython/Rust/Nim/Haskellです。
Pythonからはオフサイドルールと互換言語として多くの意味論、Rustからは式指向とトレイト、Nimからはプロシージャ、Haskellからは関数型プログラミング関連の機能を受け継いでいます。

## Pythonを呼び出せる言語はJuliaなどがあります。なぜErgを作ったのですか?

A: Ergの設計動機の1つに、手軽に使えてなおかつ強力な型システムを持った言語がほしいというものがありました。すなわち、型推論、カインド、依存型などを持った言語です。
Juliaは型付けができますが、実際のところは動的型付け言語であり、静的型付け言語のコンパイル時エラー検出というメリットを享受できません。

## Ergは関数型プログラミングやオブジェクト指向プログラミングなど複数のスタイルをサポートしています。これは、Pythonの"There should be one-- and preferably only one --obvious way to do it."に反しているのではないですか?

A: Ergでは、その言葉はもう少し狭い意味で捉えられます。例えば、一般にErgのAPIにエイリアスはありません。Ergはこの意味では"only one way"です。
関数型やOOPなどのもう少し大きな意味・枠組みでは、1つのやり方しかないというのは必ずしも利便性をもたらすとは限りません。
例えば、JavaScriptにはイミュータブルなプログラム作成を支援するライブラリが複数あり、C言語ではガベージコレクションのライブラリが複数あります。
しかし、このような基本的な機能にまでライブラリが複数あると、選定に時間を取られるだけでなく、別々のライブラリを使うコード同士の統合に著しい困難が生じます。
純粋関数型言語であるHaskellでさえ、オブジェクト指向をサポートするライブラリが存在します。
プログラマは、なければ自前で作ってしまうものなのです。それならば、標準で提供してしまったほうがよいと考えます。
これは、Pythonの"Battery included"にも適合します。

## Ergの名前の由来はなんですか?

cgs単位系のエネルギーの単位ergから名前をつけられています。プログラマーにエネルギーを与える人間工学的(ergonomic)な言語というダブルミーニングです(後付けですが)。

他にもいくつか候補はありましたが、もっとも短いこと(Rubyの作者Matz曰く、言語の名前は短い方が良いとのことです)、ググラビリティがそれなりに高いことからこれに決定されました。
