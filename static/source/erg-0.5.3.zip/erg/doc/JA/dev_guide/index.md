# Index

[![badge](https://img.shields.io/endpoint.svg?url=https%3A%2F%2Fgezf7g7pd5.execute-api.ap-northeast-1.amazonaws.com%2Fdefault%2Fsource_up_to_date%3Fowner%3Derg-lang%26repos%3Derg%26ref%3Dmain%26path%3Ddoc/EN/dev_guide/index.md%26commit_hash%3D7d43acdf0e2b71528b038b9a8e70be6c93831f96)](https://gezf7g7pd5.execute-api.ap-northeast-1.amazonaws.com/default/source_up_to_date?owner=erg-lang&repos=erg&ref=main&path=doc/EN/dev_guide/index.md&commit_hash=7d43acdf0e2b71528b038b9a8e70be6c93831f96)

## [branches](./branches.md)

## [build_features](./build_features.md)

## [directories](./directories.md)

## [doc_guideline](./doc_guideline.md)

## [env](./env.md)

## [i18n_messages](./i18n_messages.md)

## [rust_code_guideline](./rust_code_guideline.md)

