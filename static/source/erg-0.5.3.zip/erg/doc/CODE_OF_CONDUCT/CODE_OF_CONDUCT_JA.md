# 行動規範

[![badge](https://img.shields.io/endpoint.svg?url=https%3A%2F%2Fgezf7g7pd5.execute-api.ap-northeast-1.amazonaws.com%2Fdefault%2Fsource_up_to_date%3Fowner%3Derg-lang%26repos%3Derg%26ref%3Dmain%26path%3DCODE_OF_CONDUCT.md%26commit_hash%3Df2118ff45d9e46ca8fa44242363223be43b046dd)
](https://gezf7g7pd5.execute-api.ap-northeast-1.amazonaws.com/default/source_up_to_date?owner=erg-lang&repos=erg&ref=main&path=CODE_OF_CONDUCT.md&commit_hash=f2118ff45d9e46ca8fa44242363223be43b046dd)

## 全般

他者を尊重しましょう。

スキルに差があっても、意地悪なことを言ったり侮蔑したりしてはいけません。

意見の相違があっても、攻撃的になってはいけません。

他者のいかなるアイデンティティも否定してはいけません。

他者をひどく不快にする投稿をしないでください。

スパム、釣り、荒らし行為を行わないでください。

この行動規範に違反していると思われる人物を見かけた場合、すぐに[管理者](mailto:moderation.erglang@gmail.com)に連絡してください。然るべき処置を行います。