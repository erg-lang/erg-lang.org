# 行為守則

[![badge](https://img.shields.io/endpoint.svg?url=https%3A%2F%2Fgezf7g7pd5.execute-api.ap-northeast-1.amazonaws.com%2Fdefault%2Fsource_up_to_date%3Fowner%3Derg-lang%26repos%3Derg%26ref%3Dmain%26path%3DCODE_OF_CONDUCT.md%26commit_hash%3Df2118ff45d9e46ca8fa44242363223be43b046dd)
](https://gezf7g7pd5.execute-api.ap-northeast-1.amazonaws.com/default/source_up_to_date?owner=erg-lang&repos=erg&ref=main&path=CODE_OF_CONDUCT.md&commit_hash=f2118ff45d9e46ca8fa44242363223be43b046dd)

## 常規

尊重他人

即使技能上有差異，也不要說刻薄的話或表示輕蔑

不要在分歧中咄咄逼人

不要否認對方的任何身份

不要發布任何嚴重冒犯他人的內容

不要發布垃圾郵件，釣魚消息或惡意挑釁的帖子

如果您發現有人違反了本行為準則，請立即聯繫 [管理員](mailto:moderation.erglang@gmail.com)。我們將採取適當的行動
