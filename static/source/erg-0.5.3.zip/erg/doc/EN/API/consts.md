# built-in constants

## True

## False

## None

## Ellipsis

## Not Implemented

## Inf