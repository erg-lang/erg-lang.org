# module `status`

A type is defined to represent the state. Please use it by removing the option according to the situation.

* ExecResult = {"success", "warning", "failure", "fatal", "unknown"}
* ExecStatus = {"ready", "running", "sleeping", "plague", "completed", "terminated"}