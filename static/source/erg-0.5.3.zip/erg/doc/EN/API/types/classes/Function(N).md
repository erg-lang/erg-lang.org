# Function N: Nat

## methods of Function 1

* then(self, g: Self) -> Self

```python
assert f(g(x)) == f.then(g) x
```