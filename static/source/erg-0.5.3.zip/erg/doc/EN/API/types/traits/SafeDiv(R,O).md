# SafeDiv R, O

```python
SafeDiv R, O = Subsume Div, {
     @Override
     .`/` = Self.(R) -> O
}
```