# Pos

Pos is a type that represents positive numbers (integers greater than or equal to 1).
Since 0 is not included, there are merits such as eliminating the possibility of division by zero.

## Def

`Pos = 1.._`