# Either L, R = L or R

A type that represents "either L or R". You can think of it as a two-limited form of the Or type.

## methods

* orl
* orr
* andl
* andr
* mapl
* mapr