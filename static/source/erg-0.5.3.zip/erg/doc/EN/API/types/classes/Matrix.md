# Matrix T: Num, Shape: [M, N]

A type that represents a matrix. It inherits from Tensor[M, N].

## def

Inherit Tensor T, [M, N]