# Operator [...T], O

is the type of the operator.

##def

Inherit Func [...T], O