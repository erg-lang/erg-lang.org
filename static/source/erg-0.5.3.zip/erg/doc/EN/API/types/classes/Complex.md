# Complex

A type that represents a complex number. Types that represent numbers in Erg, such as Float, Int, and Nat, usually have this type at the top.

## supers

Num and Norm

## methods

* abs
* conjugate
* imag
* real