# Unary Op T, O

The type of the unary operator.

##def

Operator [T], O