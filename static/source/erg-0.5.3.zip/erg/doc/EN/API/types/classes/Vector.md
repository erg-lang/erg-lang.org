# Vector T: Num, N: Nat

A type that represents a vector. Unlike Rust and C++ types with the same name, this type only handles numbers.