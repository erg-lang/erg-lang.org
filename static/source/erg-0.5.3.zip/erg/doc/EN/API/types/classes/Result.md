# Result T, E

```python
Result T, E <: Error = Either T, E
```

Like `Option`, it represents "a value that may fail", but it can have the context of failure. Usage is almost the same as `Either`.