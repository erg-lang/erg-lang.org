# Neg

A type that represents a negative integer. Pos and Neg and {0} == Int.
It also has some notable properties such as no division by zero and Neg * Neg == Pos.

## def

Inf<..-1