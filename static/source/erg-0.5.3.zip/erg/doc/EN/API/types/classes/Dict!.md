# Dict! K, V

A type that represents a dictionary (hashmap). There is a syntactic sugar called `{K: V}`.

## methods

* invert!(self) -> Self! V, K