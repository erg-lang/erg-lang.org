# Num

## definition

```python
Num R = Add(R) and Sub(R) and Mul(R) and Eq
Num = Num Self
```

## supers

Add and Sub and Mul and Eq

## methods

*`abs`