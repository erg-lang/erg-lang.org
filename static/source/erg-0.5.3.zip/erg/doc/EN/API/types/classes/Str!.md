# StrWithLen!N: Nat! = Inherit StrWithLenN

A type that represents a variable-length string.