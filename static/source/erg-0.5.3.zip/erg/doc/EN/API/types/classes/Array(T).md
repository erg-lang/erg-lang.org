# Array T: Type

Defined by `Array T = ArrayWithLen T, _`. There is a syntactic sugar called `[T]`.