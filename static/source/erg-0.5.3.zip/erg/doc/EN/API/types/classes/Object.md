# Objects

It is the supertype of all types.

## methods

* __sizeof__: Nat