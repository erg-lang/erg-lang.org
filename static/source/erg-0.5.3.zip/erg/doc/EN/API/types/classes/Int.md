# Int

A class that represents an integer. Instances are 0, 1, -1, 300000, etc.
Many languages use Int (type equivalent to) even when representing natural numbers, but Erg uses the principle of use smaller types,
It is recommended to use Nat, NZInt, Interval type, etc.
Int is a type that comes from Python and has only `Object` as its supertype.

## supers

## methods