# BinOp L, R, O

The type of the binary operator.

## Patches

Operator [L, R], O