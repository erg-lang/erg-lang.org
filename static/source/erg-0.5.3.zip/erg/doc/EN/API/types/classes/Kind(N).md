# Kind N: Nat

```python
Kind N: Nat = (Type; N) -> Type
```
