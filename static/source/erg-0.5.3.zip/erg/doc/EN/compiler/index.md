# Index

## [abandoned](./abandoned.md)

## [architecture](./architecture.md)

## [error](./errors.md)

## [hir](./hir.md)

## [inference](./inference.md)

## [overview](./overview.md)

## [parsing](./parsing.md)

## [refinement_subtyping](./refinement_subtyping.md)

## [TODO_hint](./TODO_hint.md)

## [TODO_recov_suggest](./TODO_recov_suggest.md)

## [TODO_warn](./TODO_warn.md)

## [trait_method_resolving](./trait_method_resolving.md)

## [transpile](./transpile.md)

## [type_var_normalization.](type_var_normalization.md)