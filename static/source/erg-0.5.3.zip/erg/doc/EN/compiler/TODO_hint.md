# Hint (not implemented)

* `x is not defined` (x was deleted by `Del`) => `hint: deleted in line X`
* patch method duplication: "hint: Specify patch (like `T.foo(1)`) or delete either `.foo` using `Del`"
