# types

Types are a very important feature in Erg, so we have a [dedicated section](./type/01_type_system.md). Please see there.

<p align='center'>
     <a href='./14_set.md'>Previous</a> | <a href='./16_iterator.md'>Next</a>
</p>