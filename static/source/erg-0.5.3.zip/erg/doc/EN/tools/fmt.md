# fmt

Code formatting can be done with the fmt subcommand.
Commonly used flags are:

* explicit-type: Automatically completes where the type specification is omitted.