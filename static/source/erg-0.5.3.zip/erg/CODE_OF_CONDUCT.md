# Code of Conduct

English | <a href='./doc/CODE_OF_CONDUCT/CODE_OF_CONDUCT_JA.md'>日本語</a> | <a href='./doc/CODE_OF_CONDUCT/CODE_OF_CONDUCT_zh-CN.md'>简体中文</a> | <a href='./doc/CODE_OF_CONDUCT/CODE_OF_CONDUCT_zh-TW.md'>繁體中文</a>

## General

Respect others.

Do not say mean things or show contempt, even if there is a difference in skill.

Do not be aggressive in disagreements.

Do not deny any identity of the other person.

Do not post anything that is severely offensive to others.

Do not spam, fish or troll.

If you see someone who you think is violating this Code of Conduct, please contact the [administrator](mailto:moderation.erglang@gmail.com) immediately. We will take appropriate action.
