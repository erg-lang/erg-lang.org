//! Escape sequences change the color of the terminal

pub const RESET: &str = "\x1b[m";
pub const DEEP_RED: &str = "\x1b[31m";
pub const RED: &str = "\x1b[91m";
pub const GREEN: &str = "\x1b[92m";
pub const YELLOW: &str = "\x1b[93m";
pub const BLUE: &str = "\x1b[94m";
pub const CYAN: &str = "\x1b[96m";
