# Erg parser

## Why isn't this module but crate?

For maintainability. This crate has tests.
